0) Warning

This program might not be 100% stable. In case of bugs, report on github.

1) How to install

Copy all files to the main Tomb Raider directory. Run TombGUI.jar

2) How to use & controls

In the savemgr folder, you can put multiple folders with saves. There is an example folder for you to try.
Each save folder can have a description.txt file, that will show in the table. I recommend 3-5 words, not a long description.
The table refreshes automatically as the folder structure changes.
Double click any row to run Tomb Raider with the save files from that folder.
Click the "Clean run" button to DELETE ALL SAVES from the main Tomb Raider directory and start Tomb Raider.
You can also check out the config file to change some behaviors.

USING THIS PROGRAM WILL DELETE ALL YOUR SAVES IN THE MAIN DIRECTORY. USE IT ONLY FOR PRACTICING.


3) The Renamer.jar utility

The file is included in the package, although the source is not provided, because no updates will be needed.
When you run it, it renames the saves, so that the save file with the lowest number will be 0.
That means, if you have saves with numbers 8, 9, 11, it will rename them to 0, 1, 3. 
Basically use it, or delete it, as you wish.

___________________________
| Created by Lowosos, 2019 |
|__________________________|